import { NextResponse } from "next/server";
import { isAdminRequest } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!isAdminRequest()) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const form = await req.formData();
  const id = String(form.get("id") || "");
  if (!id) return NextResponse.redirect(new URL("/admin", req.url));

  await prisma.template.delete({ where: { id } });
  return NextResponse.redirect(new URL("/admin", req.url));
}
