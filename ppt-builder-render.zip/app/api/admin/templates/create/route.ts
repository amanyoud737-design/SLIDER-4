import { NextResponse } from "next/server";
import { isAdminRequest } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ensureDirs, UPLOAD_DIR } from "@/lib/storage";
import path from "node:path";
import crypto from "node:crypto";
import fs from "node:fs";
import sharp from "sharp";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!isAdminRequest()) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  ensureDirs();
  const form = await req.formData();
  const name = String(form.get("name") || "").trim();
  const description = String(form.get("description") || "").trim();
  const data = String(form.get("data") || "").trim();
  const thumb = form.get("thumbnail");

  if (!name || !data) return NextResponse.json({ error: "Missing fields" }, { status: 400 });

  let thumbnailPath: string | null = null;
  if (thumb instanceof File && thumb.size > 0) {
    const buf = Buffer.from(await thumb.arrayBuffer());
    const id = crypto.randomBytes(10).toString("hex");
    const filename = `tpl_${id}.webp`;
    const outPath = path.join(UPLOAD_DIR, filename);
    await sharp(buf).rotate().resize({ width: 900 }).webp({ quality: 82 }).toFile(outPath);
    thumbnailPath = `/uploads/${filename}`;
  }

  await prisma.template.create({
    data: {
      name,
      description: description || null,
      data,
      thumbnail: thumbnailPath
    }
  });

  return NextResponse.redirect(new URL("/admin", req.url));
}
