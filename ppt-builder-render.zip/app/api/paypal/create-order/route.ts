import { NextResponse } from "next/server";
import { createOrderUSD } from "@/lib/paypal";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST() {
  try{
    const order = await createOrderUSD("5.00");
    await prisma.order.create({
      data: {
        amount: 500,
        currency: "USD",
        status: "CREATED",
        paypalOrder: order.id
      }
    });
    return NextResponse.json({ id: order.id });
  } catch (e:any){
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
