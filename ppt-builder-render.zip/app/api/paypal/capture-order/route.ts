import { NextResponse } from "next/server";
import { captureOrder } from "@/lib/paypal";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { orderID } = await req.json();
  if (!orderID) return NextResponse.json({ error: "Missing orderID" }, { status: 400 });

  try{
    const result = await captureOrder(orderID);
    await prisma.order.updateMany({
      where: { paypalOrder: orderID },
      data: { status: "PAID" }
    });
    return NextResponse.json({ ok: true, result });
  } catch (e:any){
    await prisma.order.updateMany({
      where: { paypalOrder: orderID },
      data: { status: "FAILED" }
    });
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
