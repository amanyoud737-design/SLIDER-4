import { NextResponse } from "next/server";
import { ensureDirs, UPLOAD_DIR } from "@/lib/storage";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import sharp from "sharp";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  ensureDirs();
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "لا يوجد ملف" }, { status: 400 });
  }
  const buf = Buffer.from(await file.arrayBuffer());
  const ext = (file.name.split(".").pop() || "png").toLowerCase();
  const id = crypto.randomBytes(10).toString("hex");

  const safeExt = ["png","jpg","jpeg","webp"].includes(ext) ? ext : "png";
  const filename = `${id}.${safeExt}`;
  const outPath = path.join(UPLOAD_DIR, filename);

  // compress/resize a bit to keep it light
  const img = sharp(buf).rotate();
  const meta = await img.metadata();
  const w = meta.width && meta.width > 1800 ? 1800 : meta.width;
  const processed = w ? img.resize({ width: w }) : img;
  await processed.toFile(outPath);

  // served via /uploads/*
  return NextResponse.json({ url: `/uploads/${filename}` });
}
