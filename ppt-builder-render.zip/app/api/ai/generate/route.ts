import { NextResponse } from "next/server";
import type { Deck } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function fallbackDeck(title: string): Deck {
  return {
    title,
    theme: { fontFamily: "Noto Naskh Arabic", fontSize: 30, accent:"#5eead4", background:"#0b1220" },
    templateId: null,
    slides: [
      { id:"s1", title:"المقدمة", blocks:[{type:"title", text:title},{type:"paragraph", text:"مقدمة قصيرة عن الموضوع."}] as any[] },
      { id:"s2", title:"الأهداف", blocks:[{type:"title", text:"أهداف العرض"},{type:"bullets", items:["هدف 1","هدف 2","هدف 3"]}] as any[] },
      { id:"s3", title:"الخلاصة", blocks:[{type:"title", text:"الخلاصة"},{type:"bullets", items:["نقطة ختامية 1","نقطة ختامية 2"]}] as any[] }
    ]
  };
}

export async function POST(req: Request) {
  const { title } = await req.json();
  const t = String(title || "").trim();
  if (!t) return NextResponse.json({ error: "العنوان مطلوب" }, { status: 400 });

  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
  if (!apiKey) {
    return NextResponse.json({ error: "ميزة AI غير مفعلة (OPENAI_API_KEY غير موجود).", deck: fallbackDeck(t) }, { status: 400 });
  }

  // Minimal OpenAI call (no SDK) - keeps dependencies light
  try{
    const prompt = `Generate a concise Arabic slide deck outline as JSON only.
Schema:
{ "title": string, "slides": [ { "title": string, "blocks": [ { "type":"title","text":string } | { "type":"paragraph","text":string } | { "type":"bullets","items":string[] } ] } ] }
Rules:
- 6 slides
- Arabic content
- No markdown
Title: ${t}`;

    const res = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{
        "authorization": `Bearer ${apiKey}`,
        "content-type":"application/json"
      },
      body: JSON.stringify({
        model,
        input: prompt,
        max_output_tokens: 800
      })
    });

    if (!res.ok) {
      const txt = await res.text();
      return NextResponse.json({ error: txt || "OpenAI error" }, { status: 400 });
    }

    const j = await res.json();
    const text = j?.output?.[0]?.content?.[0]?.text ?? "";
    const parsed = JSON.parse(text);

    const deck: Deck = {
      title: parsed.title || t,
      theme: { fontFamily:"Noto Naskh Arabic", fontSize: 30, accent:"#5eead4", background:"#0b1220" },
      templateId: null,
      slides: (parsed.slides || []).map((s:any, idx:number)=>({
        id: `s${idx+1}`,
        title: s.title || `شريحة ${idx+1}`,
        blocks: s.blocks || [{type:"title", text:s.title || ""}]
      }))
    };

    return NextResponse.json({ deck });
  } catch(e:any){
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
