import { NextResponse } from "next/server";
import PptxGenJS from "pptxgenjs";
import type { Deck } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function rtl(text: string) {
  // PowerPoint RTL support is limited in PptxGenJS; we keep Arabic as-is.
  return text;
}

export async function POST(req: Request) {
  const deck = (await req.json()) as Deck;

  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";
  pptx.author = "PPT Builder";

  for (const s of deck.slides) {
    const slide = pptx.addSlide();
    slide.background = { color: "0B1220" };

    let y = 0.6;

    for (const b of s.blocks as any[]) {
      if (b.type === "title") {
        slide.addText(rtl(b.text || ""), {
          x: 0.6, y, w: 12.1, h: 0.8,
          fontFace: deck.theme.fontFamily,
          fontSize: Math.max(26, deck.theme.fontSize),
          bold: true,
          color: "EAF2FF",
          align: "right"
        });
        y += 1.0;
      }
      if (b.type === "paragraph") {
        slide.addText(rtl(b.text || ""), {
          x: 0.8, y, w: 11.9, h: 2.2,
          fontFace: deck.theme.fontFamily,
          fontSize: Math.max(16, Math.floor(deck.theme.fontSize * 0.55)),
          color: "9FB3C8",
          align: "right"
        });
        y += 2.0;
      }
      if (b.type === "bullets") {
        const items = Array.isArray(b.items) ? b.items : [];
        const text = items.map((t: string) => `• ${rtl(t)}`).join("\n");
        slide.addText(text, {
          x: 0.9, y, w: 11.6, h: 3.2,
          fontFace: deck.theme.fontFamily,
          fontSize: Math.max(16, Math.floor(deck.theme.fontSize * 0.55)),
          color: "9FB3C8",
          align: "right",
        });
        y += Math.min(3.2, 0.5 + items.length * 0.55);
      }
      if (b.type === "image" && b.src) {
        // image src is served from our app; client will download then we embed as link image data not supported here.
        // So we embed by URL (works in some viewers); best is to fetch and embed as data.
        // We'll fetch server-side.
        try{
          const url = b.src.startsWith("http") ? b.src : (process.env.APP_BASE_URL ? process.env.APP_BASE_URL + b.src : b.src);
          const res = await fetch(url);
          const array = await res.arrayBuffer();
          const imgData = Buffer.from(array).toString("base64");
          const contentType = res.headers.get("content-type") || "image/png";
          const dataUri = `data:${contentType};base64,${imgData}`;
          slide.addImage({ data: dataUri, x: 2.0, y, w: 9.0, h: 4.5 });
          y += 4.8;
        } catch {
          // ignore
        }
      }
    }
  }

  const buf = await pptx.write("nodebuffer");
  return new NextResponse(buf as any, {
    headers: {
      "content-type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      "content-disposition": `attachment; filename="${encodeURIComponent(deck.title || "deck")}.pptx"`
    }
  });
}
