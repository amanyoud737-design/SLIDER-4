import { NextResponse } from "next/server";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import type { Deck } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const deck = (await req.json()) as Deck;

  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica); // Arabic shaping is limited; for full Arabic PDF embed a proper Arabic font (advanced).
  // NOTE: For a production Arabic PDF, embed an Arabic font file and shape text (requires additional libs).
  // This endpoint is a "starter" PDF export. PPTX export is the primary.

  for (const s of deck.slides) {
    const page = pdf.addPage([1280, 720]);
    page.drawRectangle({ x:0, y:0, width:1280, height:720, color: rgb(0.043,0.071,0.125) });

    let y = 660;
    page.drawText(deck.title || "", { x: 40, y: 690, size: 12, font, color: rgb(0.62,0.70,0.78) });

    for (const b of s.blocks as any[]) {
      if (b.type === "title") {
        page.drawText(String(b.text || ""), { x: 40, y, size: 28, font, color: rgb(0.92,0.95,1) });
        y -= 46;
      }
      if (b.type === "paragraph") {
        const t = String(b.text || "").slice(0, 700);
        page.drawText(t, { x: 40, y, size: 14, font, color: rgb(0.62,0.70,0.78), maxWidth: 1200, lineHeight: 18 });
        y -= 90;
      }
      if (b.type === "bullets") {
        const items = Array.isArray(b.items) ? b.items : [];
        const text = items.map((it:string)=>`• ${it}`).join("\n");
        page.drawText(text, { x: 60, y, size: 14, font, color: rgb(0.62,0.70,0.78), lineHeight: 18, maxWidth: 1180 });
        y -= 20 + items.length * 18;
      }
      // images omitted in starter PDF export
    }
  }

  const bytes = await pdf.save();
  return new NextResponse(Buffer.from(bytes), {
    headers: {
      "content-type": "application/pdf",
      "content-disposition": `attachment; filename="${encodeURIComponent(deck.title || "deck")}.pdf"`
    }
  });
}
