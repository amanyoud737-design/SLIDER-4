import { NextResponse } from "next/server";
import jwt from "jsonwebtoken";

export async function POST(req: Request) {
  const deck = await req.json();
  const secret = process.env.JWT_SECRET || "dev-secret";
  const token = jwt.sign({ deck }, secret, { expiresIn: "30m" });
  return NextResponse.json({ token });
}
