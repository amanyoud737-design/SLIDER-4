"use client";

import Link from "next/link";
import { PayPalButtons, PayPalScriptProvider } from "@paypal/react-paypal-js";
import { useMemo, useState } from "react";

export default function Checkout() {
  const [status, setStatus] = useState<string>("");

  const initialOptions = useMemo(() => ({
    clientId: process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID || "test",
    currency: "USD",
    intent: "capture"
  }), []);

  return (
    <div className="container">
      <div className="topbar">
        <div style={{display:"flex", gap:10, alignItems:"center"}}>
          <Link className="btn secondary" href="/builder">رجوع</Link>
          <span className="badge">الدفع</span>
        </div>
        <Link className="btn secondary" href="/thank-you">صفحة الشكر</Link>
      </div>

      <div className="grid" style={{gridTemplateColumns:"repeat(12,1fr)"}}>
        <div className="card" style={{gridColumn:"span 7", padding:18}}>
          <div style={{fontSize:20, fontWeight:900}}>ادفع بـ PayPal</div>
          <div style={{color:"var(--muted)", marginTop:8, lineHeight:1.8}}>
            بعد الدفع سيتم تحويلك لصفحة الشكر. (هذا نموذج جاهز—تقدر لاحقًا تربط الدفع بتنزيل “مدفوع فقط”.)
          </div>

          <hr className="sep" style={{margin:"14px 0"}}/>

          <PayPalScriptProvider options={initialOptions}>
            <PayPalButtons
              style={{ layout: "vertical" }}
              createOrder={async () => {
                const res = await fetch("/api/paypal/create-order", { method: "POST" });
                const j = await res.json();
                if (!res.ok) throw new Error(j?.error || "فشل إنشاء الطلب");
                return j.id;
              }}
              onApprove={async (data) => {
                setStatus("جاري تأكيد الدفع...");
                const res = await fetch("/api/paypal/capture-order", {
                  method: "POST",
                  headers: { "content-type": "application/json" },
                  body: JSON.stringify({ orderID: data.orderID })
                });
                const j = await res.json();
                if (!res.ok) {
                  setStatus("فشل الدفع: " + (j?.error || ""));
                  return;
                }
                window.location.href = "/thank-you";
              }}
              onError={(err) => {
                setStatus("خطأ: " + String(err));
              }}
            />
          </PayPalScriptProvider>

          {status && <div className="badge" style={{marginTop:12}}>{status}</div>}
        </div>

        <div className="card" style={{gridColumn:"span 5", padding:18}}>
          <div style={{fontWeight:900}}>المبلغ</div>
          <div style={{fontSize:34, fontWeight:900, marginTop:10}}>$5</div>
          <div style={{color:"var(--muted)", marginTop:8}}>
            غيّر السعر من API بسهولة لاحقًا.
          </div>
          <hr className="sep" style={{margin:"14px 0"}}/>
          <div style={{color:"var(--muted)", lineHeight:1.8}}>
            للتفعيل على Render:
            <ul>
              <li>ضع NEXT_PUBLIC_PAYPAL_CLIENT_ID</li>
              <li>ضع PAYPAL_CLIENT_SECRET</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
