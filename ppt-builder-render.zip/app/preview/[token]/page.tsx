import jwt from "jsonwebtoken";
import Link from "next/link";
import type { Deck } from "@/lib/types";

export const dynamic = "force-dynamic";

function verify(token: string): Deck | null {
  const secret = process.env.JWT_SECRET || "dev-secret";
  try {
    const payload = jwt.verify(token, secret) as any;
    return payload.deck as Deck;
  } catch {
    return null;
  }
}

export default function Preview({ params }: { params: { token: string } }) {
  const deck = verify(params.token);
  if (!deck) {
    return (
      <div className="container">
        <div className="card" style={{padding:18}}>
          <div style={{fontWeight:900, fontSize:18}}>المعاينة غير متاحة</div>
          <div style={{color:"var(--muted)", marginTop:8}}>انتهت صلاحية الرابط أو غير صحيح.</div>
          <Link className="btn secondary" href="/builder" style={{display:"inline-block", marginTop:12}}>رجوع للمحرر</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="topbar">
        <div style={{display:"flex", gap:10, alignItems:"center"}}>
          <Link className="btn secondary" href="/builder">رجوع</Link>
          <span className="badge">معاينة</span>
        </div>
        <Link className="btn" href="/checkout">الدفع</Link>
      </div>

      <div className="card" style={{padding:18}}>
        <div style={{fontSize:22, fontWeight:900}}>{deck.title}</div>
        <div style={{color:"var(--muted)", marginTop:6}}>عرض كامل قبل الدفع (بدون دخول).</div>
        <hr className="sep" style={{margin:"14px 0"}}/>

        <div className="grid" style={{gridTemplateColumns:"repeat(12,1fr)"}}>
          {deck.slides.map((s) => (
            <div key={s.id} className="card" style={{gridColumn:"span 6", padding:14, background:"rgba(2,6,23,.35)", fontFamily: deck.theme.fontFamily}}>
              <div style={{color:"var(--muted)", fontSize:12, marginBottom:8}}>{s.title}</div>
              {s.blocks.map((b:any, i:number)=>(
                <div key={i} style={{marginBottom:10}}>
                  {b.type==="title" && <div style={{fontWeight:900, fontSize: deck.theme.fontSize}}>{b.text}</div>}
                  {b.type==="paragraph" && <div style={{color:"var(--muted)", lineHeight:1.8}}>{b.text}</div>}
                  {b.type==="bullets" && (
                    <ul style={{color:"var(--muted)", margin:"6px 0 0 0", paddingInlineStart:18}}>
                      {b.items?.map((it:string, k:number)=> <li key={k} style={{marginBottom:4}}>{it}</li>)}
                    </ul>
                  )}
                  {b.type==="image" && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img alt="img" src={b.src} style={{width:"100%", borderRadius:12, border:"1px solid var(--border)"}} />
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
