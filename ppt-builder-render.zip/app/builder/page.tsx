"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { FONT_OPTIONS } from "@/lib/fonts";
import type { Deck, Slide, SlideBlock } from "@/lib/types";

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

const DEFAULT_DECK: Deck = {
  title: "عرض جديد",
  theme: {
    fontFamily: "Noto Naskh Arabic",
    fontSize: 28,
    accent: "#5eead4",
    background: "#0b1220"
  },
  templateId: null,
  slides: [
    {
      id: "s1",
      title: "شريحة 1",
      blocks: [
        { type: "title", text: "عنوان العرض" },
        { type: "bullets", items: ["نقطة 1", "نقطة 2", "نقطة 3"] }
      ]
    }
  ]
};

export default function Builder({ searchParams }: { searchParams: { templateId?: string } }) {
  const [deck, setDeck] = useState<Deck>(() => ({
    ...DEFAULT_DECK,
    templateId: searchParams?.templateId || null
  }));
  const [activeId, setActiveId] = useState(deck.slides[0]?.id ?? "s1");
  const [busy, setBusy] = useState(false);
  const activeSlide = useMemo(() => deck.slides.find(s => s.id === activeId) ?? deck.slides[0], [deck, activeId]);

  useEffect(() => {
    if (!activeSlide && deck.slides[0]) setActiveId(deck.slides[0].id);
  }, [activeSlide, deck.slides]);

  function updateSlide(partial: Partial<Slide>) {
    setDeck(d => ({
      ...d,
      slides: d.slides.map(s => s.id === activeId ? { ...s, ...partial } : s)
    }));
  }

  function updateBlock(index: number, block: SlideBlock) {
    updateSlide({ blocks: activeSlide.blocks.map((b, i) => i === index ? block : b) });
  }

  function addSlide() {
    const id = uid();
    const s: Slide = {
      id,
      title: `شريحة ${deck.slides.length + 1}`,
      blocks: [{ type: "title", text: `عنوان الشريحة` }, { type: "paragraph", text: "اكتب هنا..." }]
    };
    setDeck(d => ({ ...d, slides: [...d.slides, s] }));
    setActiveId(id);
  }

  function deleteSlide(id: string) {
    setDeck(d => ({ ...d, slides: d.slides.filter(s => s.id !== id) }));
    if (activeId === id) {
      const next = deck.slides.find(s => s.id !== id);
      if (next) setActiveId(next.id);
    }
  }

  async function uploadImage(file: File) {
    const form = new FormData();
    form.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body: form });
    if (!res.ok) throw new Error("فشل رفع الصورة");
    return (await res.json()) as { url: string };
  }

  async function download(kind: "pptx" | "pdf") {
    setBusy(true);
    try{
      const res = await fetch(`/api/export/${kind}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(deck),
      });
      if (!res.ok) throw new Error("فشل التصدير");
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${deck.title}.${kind}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(a.href);
    } finally {
      setBusy(false);
    }
  }

  async function toPreview() {
    setBusy(true);
    try {
      const res = await fetch("/api/preview-token", {
        method:"POST",
        headers:{ "content-type":"application/json" },
        body: JSON.stringify(deck)
      });
      const j = await res.json();
      window.open(`/preview/${j.token}`, "_blank");
    } finally {
      setBusy(false);
    }
  }

  async function aiGenerate() {
    const title = prompt("اكتب عنوان العرض فقط:");
    if (!title) return;
    setBusy(true);
    try{
      const res = await fetch("/api/ai/generate", {
        method:"POST",
        headers:{ "content-type":"application/json" },
        body: JSON.stringify({ title })
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j?.error || "فشل توليد العرض");
      setDeck(j.deck);
      setActiveId(j.deck.slides[0]?.id);
    } catch(e:any){
      alert(e.message);
    } finally{
      setBusy(false);
    }
  }

  return (
    <div className="container">
      <div className="topbar">
        <div style={{display:"flex", gap:10, alignItems:"center"}}>
          <Link className="btn secondary" href="/">رجوع</Link>
          <span className="badge">المحرّر</span>
          {deck.templateId ? <span className="badge">قالب: {deck.templateId}</span> : <span className="badge">بدون قالب</span>}
        </div>
        <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
          <button className="btn secondary" onClick={aiGenerate} disabled={busy}>AI توليد</button>
          <button className="btn secondary" onClick={toPreview} disabled={busy}>معاينة</button>
          <Link className="btn secondary" href="/checkout">الدفع</Link>
          <button className="btn" onClick={() => download("pptx")} disabled={busy}>تنزيل PPTX</button>
          <button className="btn" onClick={() => download("pdf")} disabled={busy}>تنزيل PDF</button>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:"320px 1fr 360px", alignItems:"start"}}>
        {/* Thumbnails */}
        <div className="card" style={{padding:12}}>
          <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10}}>
            <div style={{fontWeight:900}}>الشرائح</div>
            <button className="btn" onClick={addSlide}>+ إضافة</button>
          </div>
          <div className="grid" style={{gap:10}}>
            {deck.slides.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => setActiveId(s.id)}
                style={{
                  textAlign:"right",
                  width:"100%",
                  padding:10,
                  borderRadius:14,
                  border:"1px solid var(--border)",
                  background: s.id === activeId ? "rgba(94,234,212,.12)" : "rgba(2,6,23,.35)",
                  cursor:"pointer"
                }}
              >
                <div style={{display:"flex", justifyContent:"space-between", gap:10}}>
                  <div>
                    <div style={{fontWeight:900}}>{idx+1}. {s.title}</div>
                    <div style={{color:"var(--muted)", fontSize:12, marginTop:4}}>
                      {s.blocks.find(b => b.type === "title")?.type === "title" ? (s.blocks.find(b => b.type==="title") as any).text : "—"}
                    </div>
                  </div>
                  <span
                    onClick={(e)=>{ e.stopPropagation(); if(confirm("حذف الشريحة؟")) deleteSlide(s.id); }}
                    style={{color:"var(--danger)", fontWeight:900}}
                    title="حذف"
                  >
                    ✕
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Editor */}
        <div className="card" style={{padding:14}}>
          <div style={{display:"flex", justifyContent:"space-between", gap:12, flexWrap:"wrap", alignItems:"center"}}>
            <input
              className="input"
              value={deck.title}
              onChange={(e)=>setDeck(d=>({...d, title:e.target.value}))}
              style={{maxWidth: 420}}
              placeholder="عنوان المشروع"
            />
            <div style={{display:"flex", gap:10, alignItems:"center", flexWrap:"wrap"}}>
              <select className="select" value={deck.theme.fontFamily} onChange={(e)=>setDeck(d=>({...d, theme:{...d.theme, fontFamily:e.target.value}}))}>
                {FONT_OPTIONS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
              </select>
              <div style={{display:"flex", gap:10, alignItems:"center"}}>
                <span style={{color:"var(--muted)"}}>الحجم</span>
                <input
                  type="range"
                  min={18}
                  max={44}
                  value={deck.theme.fontSize}
                  onChange={(e)=>setDeck(d=>({...d, theme:{...d.theme, fontSize:Number(e.target.value)}}))}
                />
                <span className="badge">{deck.theme.fontSize}</span>
              </div>
            </div>
          </div>

          <hr className="sep" style={{margin:"14px 0"}}/>

          {!activeSlide ? (
            <div style={{color:"var(--muted)"}}>لا يوجد شريحة.</div>
          ) : (
            <div className="grid" style={{gap:12}}>
              <input
                className="input"
                value={activeSlide.title}
                onChange={(e)=>updateSlide({ title: e.target.value })}
                placeholder="اسم الشريحة (داخلي)"
              />

              {activeSlide.blocks.map((b, idx) => (
                <div key={idx} className="card" style={{padding:12, background:"rgba(2,6,23,.35)"}}>
                  <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8}}>
                    <span className="badge">{b.type}</span>
                    <button className="btn danger" onClick={() => updateSlide({ blocks: activeSlide.blocks.filter((_,i)=>i!==idx) })}>حذف</button>
                  </div>

                  {b.type === "title" && (
                    <input className="input" value={b.text} onChange={(e)=>updateBlock(idx, { ...b, text: e.target.value })} placeholder="العنوان" />
                  )}

                  {b.type === "paragraph" && (
                    <textarea className="textarea" value={b.text} onChange={(e)=>updateBlock(idx, { ...b, text: e.target.value })} placeholder="النص" />
                  )}

                  {b.type === "bullets" && (
                    <textarea
                      className="textarea"
                      value={b.items.join("\n")}
                      onChange={(e)=>updateBlock(idx, { ...b, items: e.target.value.split("\n").map(s=>s.trim()).filter(Boolean) })}
                      placeholder={"اكتب كل نقطة بسطر"}
                    />
                  )}

                  {b.type === "image" && (
                    <div className="grid">
                      <input className="input" value={b.caption ?? ""} onChange={(e)=>updateBlock(idx, { ...b, caption: e.target.value })} placeholder="تعليق (اختياري)" />
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img alt="img" src={b.src} style={{width:"100%", borderRadius:14, border:"1px solid var(--border)"}} />
                    </div>
                  )}
                </div>
              ))}

              <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
                <button className="btn secondary" onClick={() => updateSlide({ blocks: [...activeSlide.blocks, { type:"title", text:"عنوان جديد" }] })}>+ عنوان</button>
                <button className="btn secondary" onClick={() => updateSlide({ blocks: [...activeSlide.blocks, { type:"paragraph", text:"" }] })}>+ فقرة</button>
                <button className="btn secondary" onClick={() => updateSlide({ blocks: [...activeSlide.blocks, { type:"bullets", items: [] }] })}>+ نقاط</button>

                <label className="btn secondary" style={{display:"inline-flex", alignItems:"center", gap:8}}>
                  + صورة
                  <input
                    type="file"
                    accept="image/*"
                    hidden
                    onChange={async (e)=>{
                      const f = e.target.files?.[0];
                      if (!f) return;
                      try{
                        setBusy(true);
                        const { url } = await uploadImage(f);
                        updateSlide({ blocks: [...activeSlide.blocks, { type:"image", src:url, caption:"" }] });
                      } catch(err:any){
                        alert(err.message);
                      } finally{
                        setBusy(false);
                        e.target.value = "";
                      }
                    }}
                  />
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Live Preview (all slides) */}
        <div className="card" style={{padding:12}}>
          <div style={{fontWeight:900, marginBottom:10}}>معاينة فورية (كل الشرائح)</div>
          <div className="grid" style={{gap:10}}>
            {deck.slides.map((s) => (
              <div key={s.id} className="card" style={{padding:12, background:"rgba(2,6,23,.35)", fontFamily: deck.theme.fontFamily}}>
                <div style={{fontSize: 14, color:"var(--muted)", marginBottom:6}}>{s.title}</div>
                {s.blocks.map((b, i) => (
                  <div key={i} style={{marginBottom:8}}>
                    {b.type === "title" && (
                      <div style={{fontWeight:900, fontSize: Math.max(18, deck.theme.fontSize)}}>{b.text}</div>
                    )}
                    {b.type === "paragraph" && (
                      <div style={{color:"var(--muted)", lineHeight:1.7, fontSize: 14}}>{b.text}</div>
                    )}
                    {b.type === "bullets" && (
                      <ul style={{color:"var(--muted)", margin:"6px 0 0 0", paddingInlineStart:18}}>
                        {b.items.map((it, k) => <li key={k} style={{marginBottom:4}}>{it}</li>)}
                      </ul>
                    )}
                    {b.type === "image" && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img alt="img" src={b.src} style={{width:"100%", borderRadius:12, border:"1px solid var(--border)"}} />
                    )}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
