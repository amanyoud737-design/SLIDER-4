import Link from "next/link";

export default function Demo() {
  return (
    <div className="container">
      <div className="topbar">
        <Link className="btn secondary" href="/">رجوع</Link>
        <span className="badge">Demo</span>
      </div>
      <div className="card" style={{padding:18, color:"var(--muted)", lineHeight:1.9}}>
        هذه صفحة مثال بسيطة. افتح المحرر وجرّب المعاينة والتصدير.
        <div style={{marginTop:14}}>
          <Link className="btn" href="/builder">المحرر</Link>
        </div>
      </div>
    </div>
  );
}
