import Link from "next/link";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Templates() {
  const templates = await prisma.template.findMany({ orderBy: { createdAt: "desc" } });
  return (
    <div className="container">
      <div className="topbar">
        <div style={{display:"flex", gap:10, alignItems:"center"}}>
          <Link className="btn secondary" href="/">رجوع</Link>
          <span className="badge">القوالب</span>
        </div>
        <Link className="btn" href="/builder">استخدام المحرر</Link>
      </div>

      <div className="grid" style={{gridTemplateColumns:"repeat(12,1fr)"}}>
        {templates.map(t => (
          <div key={t.id} className="card" style={{gridColumn:"span 4"}}>
            <div style={{padding:14}}>
              <div style={{fontWeight:900, fontSize:16}}>{t.name}</div>
              <div style={{color:"var(--muted)", marginTop:6, minHeight:44}}>
                {t.description || "—"}
              </div>
              {t.thumbnail ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img alt={t.name} src={t.thumbnail} style={{width:"100%", borderRadius:14, marginTop:10, border:"1px solid var(--border)"}} />
              ) : (
                <div style={{marginTop:10, padding:18, border:"1px dashed var(--border)", borderRadius:14, color:"var(--muted)"}}>
                  لا يوجد صورة
                </div>
              )}

              <Link className="btn" href={`/builder?templateId=${t.id}`} style={{display:"inline-block", marginTop:12}}>
                استخدم هذا القالب
              </Link>
            </div>
          </div>
        ))}

        {templates.length === 0 && (
          <div className="card" style={{gridColumn:"span 12", padding:18, color:"var(--muted)"}}>
            لا يوجد قوالب بعد. ادخل لوحة الأدمن وأضف أول قالب.
          </div>
        )}
      </div>
    </div>
  );
}
