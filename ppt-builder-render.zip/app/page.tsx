import Link from "next/link";

export default function Home() {
  return (
    <div className="container">
      <div className="topbar">
        <div>
          <div style={{fontSize: 28, fontWeight: 900}}>مُصمِّم العروض الاحترافي</div>
          <div style={{color:"var(--muted)", marginTop: 6}}>
            اكتب المحتوى، اختر الخط والقالب، شاهد المعاينة، ثم ادفع وحمّل PPTX/PDF.
          </div>
        </div>
        <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
          <Link className="btn secondary" href="/admin">لوحة الأدمن</Link>
          <Link className="btn" href="/builder">ابدأ الآن</Link>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:"repeat(12,1fr)"}}>
        <div className="card" style={{gridColumn:"span 7", padding:18}}>
          <div style={{fontSize:18, fontWeight:900, marginBottom:10}}>ماذا يوفر الموقع؟</div>
          <ul style={{lineHeight: 1.9, color:"var(--muted)", marginTop:0}}>
            <li>محرّر شرائح: كل الشرائح أمامك (مصغّرات + تحرير سريع).</li>
            <li>رفع صور من الجهاز + وضعها داخل الشرائح.</li>
            <li>خطوط عربية جاهزة (رقعة/نسخ/كوفي/…)، وتغيير حجم الخط.</li>
            <li>توليد عرض بالذكاء الاصطناعي بالعنوان فقط (اختياري).</li>
            <li>دفع PayPal ثم صفحة شكر وتنزيل الملفات.</li>
          </ul>
          <div style={{display:"flex", gap:10, marginTop:14, flexWrap:"wrap"}}>
            <Link className="btn" href="/builder">فتح المحرر</Link>
            <Link className="btn secondary" href="/templates">استعراض القوالب</Link>
          </div>
        </div>

        <div className="card" style={{gridColumn:"span 5", padding:18}}>
          <div style={{fontSize:18, fontWeight:900, marginBottom:10}}>ملاحظة مهمة</div>
          <div style={{color:"var(--muted)", lineHeight:1.8}}>
            الدفع مضبوط بـ PayPal. لتشغيل “الذكاء الاصطناعي” تحتاج مفتاح API وتضعه في متغيرات Render.
            لوحة الأدمن محمية بيوزر/باسورد من البيئة.
          </div>
          <hr className="sep" style={{margin:"16px 0"}}/>
          <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
            <Link className="btn secondary" href="/how">طريقة الاستخدام</Link>
            <Link className="btn secondary" href="/preview-demo">معاينة مثال</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
