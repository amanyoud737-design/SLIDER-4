import Link from "next/link";

export default function How() {
  return (
    <div className="container">
      <div className="topbar">
        <Link className="btn secondary" href="/">رجوع</Link>
        <span className="badge">دليل سريع</span>
      </div>

      <div className="card" style={{padding:18, lineHeight:1.9}}>
        <div style={{fontSize:20, fontWeight:900}}>طريقة الاستخدام</div>
        <ol style={{color:"var(--muted)"}}>
          <li>ادخل على صفحة <b>/builder</b>.</li>
          <li>أضف شرائح، اكتب العناوين والنقاط، وارفع صور من جهازك.</li>
          <li>اختر الخط وحجم الخط والقالب.</li>
          <li>اضغط <b>معاينة</b> لتشوف العرض كامل قبل الدفع.</li>
          <li>انتقل لصفحة الدفع PayPal، وبعد الدفع تحصل التنزيل.</li>
        </ol>

        <div style={{display:"flex", gap:10}}>
          <Link className="btn" href="/builder">ابدأ</Link>
          <Link className="btn secondary" href="/templates">القوالب</Link>
        </div>
      </div>
    </div>
  );
}
