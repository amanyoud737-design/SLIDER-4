export const FONT_OPTIONS = [
  { label: "نسخ (Noto Naskh Arabic)", value: "Noto Naskh Arabic" },
  { label: "رقعة (Aref Ruqaa)", value: "Aref Ruqaa" },
  { label: "كوفي (Reem Kufi)", value: "Reem Kufi" },
  { label: "مصري/حديث (Cairo)", value: "Cairo" },
  { label: "أميري (Amiri)", value: "Amiri" }
  // الديواني: أضِفه يدويًا إذا عندك ملف الخط وترخيصه
];
