ضع ملفات الخطوط هنا بصيغة TTF/OTF (مفتوحة المصدر أو مرخّصة لك).

الأسماء التي يتوقعها المشروع افتراضيًا:
- ArefRuqaa-Regular.ttf
- NotoNaskhArabic-Regular.ttf
- ReemKufi-Regular.ttf
- Cairo-Regular.ttf
- Amiri-Regular.ttf

يمكنك تغيير أسماء الملفات في app/globals.css إذا رغبت.
